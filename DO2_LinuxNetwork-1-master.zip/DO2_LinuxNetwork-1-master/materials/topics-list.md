Hello, School21 student! 😉

To help you navigate through the material, we have prepared a list of topics that you will learn in this project.

We will learn:

- Routing;
- TCP/IP;
- Ports;
- Firewall (iptables);
- DHCP;
- NAT;
- Using utils in terminal (ipcalc/iperf3);
- ssh tunnels.

Now that you know what to expect in this project, you can slowly start to study the topics listed above. 😇
